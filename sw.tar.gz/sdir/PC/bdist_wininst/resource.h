/*
  IMPORTANT NOTE: IF THIS FILE IS CHANGED, WININST-6.EXE MUST BE RECOMPILED
  WITH THE MSVC6 WININST.DSW WORKSPACE FILE MANUALLY, AND WININST-7.1.EXE MUST
  BE RECOMPILED WITH THE MSVC 2003.NET WININST-7.1.VCPROJ FILE MANUALLY.

  IF CHANGES TO THIS FILE ARE CHECKED INTO PYTHON CVS, THE RECOMPILED BINARIES
  MUST BE CHECKED IN AS WELL!
*/

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by install.rc
//
#define IDD_DIALOG1                     101
#define IDB_BITMAP1                     103
#define IDD_INTRO                       107
#define IDD_SELECTPYTHON                108
#define IDD_INSTALLFILES                109
#define IDD_FINISHED                    110
#define IDB_BITMAP                      110
#define IDC_EDIT1                       1000
#define IDC_TITLE                       1000
#define IDC_START                       1001
#define IDC_PROGRESS                    1003
#define IDC_INFO                        1004
#define IDC_PYTHON15                    1006
#define IDC_PATH                        1007
#define IDC_PYTHON16                    1008
#define IDC_INSTALL_PATH                1008
#define IDC_PYTHON20                    1009
#define IDC_BROWSE                      1010
#define IDC_INTRO_TEXT                  1021
#define IDC_VERSIONS_LIST               1022
#define IDC_BUILD_INFO                  1024
#define IDC_BITMAP                      1025
#define IDC_OTHERPYTHON                 1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
